package com.example.recyclerviewexample;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerview);


        List<Item> items = new ArrayList<Item>();
        items.add(new Item("John Wick","JohnWick@gmail.com", R.drawable.a));
        items.add(new Item("Selena Gomez","Selenagomez@gmail.com", R.drawable.b));
        items.add(new Item("MandyTeefy","MandyTeefy@gmail.com", R.drawable.c));
        items.add(new Item("Paul Walker","PaulWalker@gmail.com", R.drawable.d));

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new MyAdapter(getApplicationContext(),items));
    }
}